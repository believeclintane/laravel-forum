<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Channels</div>

                <div class="card-body">
                     <table class="table table-responsive table-hover">
<thead>
    <th>
        name
    </th>
    <th>
        edit
    </th>
    <th>delete</th>
</thead>
<tbody>
    <?php $__currentLoopData = $channels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $channel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($channel->title); ?></td>
            <td>
                 <a href="<?php echo e(route('channels.edit',['channel' => $channel->id])); ?>" class="btn btn-xs btn-warning"> Edit</a>
            </td>
            <td>
                                          <form action="<?php echo e(route('channels.destroy',['channel' => $channel->id])); ?>" method="post">
                                        <?php echo e(csrf_field()); ?> 

                                        <?php echo e(method_field('DELETE')); ?>

                                        <button  type="submit" class="btn btn-xs btn-danger"> Delete</button>
                                        </form>
                                        
                                    </td>
        </tr>
        
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</tbody>
                     </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->startSection('content'); ?>
<?php $__currentLoopData = $ds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="card mb-2">
    <div class="card-header">
        <img src="<?php echo e($d->user->avatar); ?>" height='40px' width="40px" alt="">
        <span><?php echo e($d->user->name); ?> <?php echo e($d->created_at->diffForHumans()); ?></span>

        <?php if($d->hasBestAnswer()): ?>
        <span class="badge badge-info">CLOSED</span>
        <?php endif; ?>
        <span><a href="<?php echo e(route('discussion',['slug' => $d->slug])); ?>" class="btn btn-secondary float-right ">veiw</a></span>
    </div>

    <div class="card-body">
        <h5><?php echo e($d->title); ?></h5>
      <p>  <?php echo e(str_limit($d->content,60)); ?></p>
    </div>
    <div class="card-footer">
        <?php echo e($d->reply->count()); ?> Replies
    </div>
 </div>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<div class="text-center">
    <?php echo e($ds->links()); ?>

</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
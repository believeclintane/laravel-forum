<?php $__env->startSection('content'); ?>
 
            <div class="card">
                <div class="card-header"> Edit channel <?php echo e($channel->title); ?></div>

                <div class="card-body">
                    <form method="POST" action="<?php echo e(route('channels.update',['channel' =>$channel->id])); ?>">
<?php echo e(csrf_field()); ?>


   <div class="form-group">
       <input type="text" name="channel" class="form-control" placeholder="<?php echo e($channel->title); ?>">
   </div>   

   <div class="form-group text-center">
       <button class="btn-success btn" type="submit">
          update
       </button>
   </div>    
   
   </form>
                </div>
            </div>
     
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->startSection('content'); ?>

            <div class="card">
                <div class="card-header center">Update Discussion</div>

                <div class="card-body">
                   <form method="post" action="<?php echo e(route('discussion.update',['id'=> $d->id])); ?>">

<?php echo e(csrf_field()); ?>


      <div class="form-group">
          <label for="content"> Ask a Question</label>
          <textarea class="form-control" name="content" id="content" cols="30" rows="10"> <?php echo e($d->content); ?> </textarea>
      </div>

      <div class="form-group">
          <button type="submit" class="btn btn-success">
              submit
          </button>
      </div>
  </div>
                   </form>
                </div>
            </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
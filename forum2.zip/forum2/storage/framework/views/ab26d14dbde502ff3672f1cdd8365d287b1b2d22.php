<?php $__env->startSection('content'); ?>

            <div class="card">
                <div class="card-header center">Dashboard</div>

                <div class="card-body">
                   <form method="post" action="<?php echo e(route('discussion.store')); ?>">

<?php echo e(csrf_field()); ?>

<div class="form-group">
    <label for="title"> discussion title</label>
    <input type="text" id="title" value="<?php echo e(old('title')); ?>" name="title" class="form-control">
</div>
  <div class="form-group">

      <label for="ch">pick a channel</label>
      <select name="channel_id" id="ch" class="form-control">
           <?php $__currentLoopData = $channels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $channel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
               <option value="<?php echo e($channel->id); ?>"  class="form-control"> <?php echo e($channel->title); ?> </option>
           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </select>
      <div class="form-group">
          <label for="content"> Ask a Question</label>
          <textarea class="form-control" name="content" id="content" cols="30" rows="10"></textarea>
      </div>

      <div class="form-group">
          <button type="submit" class="btn btn-success">
              submit
          </button>
      </div>
  </div>
                   </form>
                </div>
            </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>